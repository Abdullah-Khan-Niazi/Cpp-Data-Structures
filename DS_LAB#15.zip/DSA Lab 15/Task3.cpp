//#include <iostream>
//using namespace std;
//
//struct Edge
//{
//    int u, v, weight;
//};
//
//void sortEdges(Edge edges[], int n)
//{
//    for (int i = 0; i < n - 1; i++)
//    {
//        for (int j = 0; j < n - i - 1; j++)
//        {
//            if (edges[j].weight > edges[j + 1].weight)
//            {
//                Edge temp = edges[j];
//                edges[j] = edges[j + 1];
//                edges[j + 1] = temp;
//            }
//        }
//    }
//}
//
//int findParent(int node, int parent[])
//{
//    while (parent[node] != node)
//    {
//        node = parent[node];
//    }
//    return node;
//}
//
//void unionNodes(int u, int v, int parent[], int rank[])
//{
//    int parentU = findParent(u, parent);
//    int parentV = findParent(v, parent);
//
//    if (rank[parentU] > rank[parentV])
//    {
//        parent[parentV] = parentU;
//    }
//    else if (rank[parentU] < rank[parentV])
//    {
//        parent[parentU] = parentV;
//    }
//    else
//    {
//        parent[parentV] = parentU;
//        rank[parentU]++;
//    }
//}
//
//void kruskal(Edge edges[], int numVertices, int numEdges)
//{
//    int* parent = new int[numVertices + 1];
//    int* rank = new int[numVertices + 1];
//
//    for (int i = 1; i <= numVertices; i++)
//    {
//        parent[i] = i;
//        rank[i] = 0;
//    }
//
//    sortEdges(edges, numEdges);
//
//    int totalCost = 0;
//    cout << "Selected connections: ";
//
//    for (int i = 0; i < numEdges; i++)
//    {
//        int u = edges[i].u;
//        int v = edges[i].v;
//
//        if (findParent(u, parent) != findParent(v, parent))
//        {
//            totalCost += edges[i].weight;
//            cout << "(" << u << ", " << v << ") ";
//            unionNodes(u, v, parent, rank);
//        }
//    }
//
//    cout << "\nTotal cost: " << totalCost << endl;
//
//    delete[] parent;
//    delete[] rank;
//}
//
//int main()
//{
//    const int numVertices = 6;
//    const int numEdges = 9;
//
//    Edge edges[] = { {1, 2, 4}, {1, 3, 3}, {2, 3, 1}, {2, 4, 2},{3, 4, 5}, {3, 5, 7}, {4, 5, 6}, {4, 6, 8}, {5, 6, 9} };
//
//    kruskal(edges, numVertices, numEdges);
//
//    return 0;
//}
