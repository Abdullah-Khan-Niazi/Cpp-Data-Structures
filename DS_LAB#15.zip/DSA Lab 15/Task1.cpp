//#include <iostream>
//using namespace std;
//
//class Graph {
//    int** matrix;
//    bool* visited;
//    int offices;
//
//public:
//    Graph(int n) {
//        offices = n;
//        matrix = new int* [n];
//        for (int i = 0; i < n; i++) {
//            matrix[i] = new int[n];
//            for (int j = 0; j < n; j++)
//                matrix[i][j] = 0;
//        }
//        visited = new bool[n];
//    }
//
//    ~Graph() {
//        for (int i = 0; i < offices; i++)
//            delete[] matrix[i];
//        delete[] matrix;
//        delete[] visited;
//    }
//
//    void addEdge(int x, int y) {
//        x--;
//        y--;
//        matrix[x][y] = 1;
//        matrix[y][x] = 1;
//    }
//
//    void reset_visited() {
//        for (int i = 0; i < offices; i++)
//            visited[i] = false;
//    }
//
//    void dfs(int start) {
//        visited[start] = true;
//
//        for (int i = 0; i < offices; i++) {
//            if (matrix[start][i] == 1 && !visited[i]) {
//                dfs(i);
//            }
//        }
//    }
//
//    int countGroups() {
//        int groups = 0;
//        reset_visited();
//
//        for (int i = 0; i < offices; i++) {
//            if (!visited[i]) {
//                dfs(i);
//                groups++;
//            }
//        }
//        return groups;
//    }
//};
//
//int main() {
//    int n = 6;
//    Graph network(n);
//
//    network.addEdge(1, 2);
//    network.addEdge(2, 3);
//    network.addEdge(4, 5);
//
//
//    int groups = network.countGroups();
//
//    if (groups == 1)
//        cout << "Network is fully connected!" << endl;
//    else
//        cout << "Network is not fully connected. Number of isolated groups: " << groups << endl;
//
//    return 0;
//}