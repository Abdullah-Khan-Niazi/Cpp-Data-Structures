//#include <iostream>
//using namespace std;
//
//class Queue
//{
//    int data[100];
//    int front, rear;
//
//public:
//    Queue()
//    {
//        front = rear = -1;
//    }
//
//    void enqueue(int value)
//    {
//        if (rear == 99)
//        {
//            return;
//        }
//        if (front == -1)
//        {
//            front = 0;
//        }
//        data[++rear] = value;
//    }
//
//    int dequeue()
//    {
//        if (front == -1 || front > rear)
//        {
//            return -1;
//        }
//        return data[front++];
//    }
//
//    bool isEmpty()
//    {
//        return front == -1 || front > rear;
//    }
//};
//
//void findShortestPath(int graph[][7], int start, int end, int n)
//{
//    bool visited[7] = { false };
//    int parent[7] = { -1 };
//    Queue q;
//
//    q.enqueue(start);
//    visited[start] = true;
//
//    while (!q.isEmpty())
//    {
//        int current = q.dequeue();
//        for (int i = 0; i < n; i++)
//        {
//            if (graph[current][i] == 1 && !visited[i])
//            {
//                visited[i] = true;
//                parent[i] = current;
//                q.enqueue(i);
//                if (i == end)
//                {
//                    break;
//                }
//            }
//        }
//    }
//
//    if (!visited[end])
//    {
//        cout << "No path exists.\n";
//        return;
//    }
//
//    int path[7];
//    int index = 0;
//    for (int i = end; i != -1; i = parent[i])
//    {
//        path[index++] = i;
//    }
//
//    cout << "Shortest route length: " << index - 1 << " and Route: ";
//    for (int i = index - 1; i >= 0; i--)
//    {
//        cout << path[i] + 1;
//        if (i > 0)
//        {
//            cout << " -> ";
//        }
//    }
//    cout << endl;
//}
//
//int main()
//{
//    int graph[7][7] = { 0 };
//    graph[0][1] = 1;
//    graph[0][2] = 1;
//    graph[1][3] = 1;
//    graph[2][4] = 1;
//    graph[4][5] = 1;
//    graph[5][3] = 1;
//
//    int start = 0, end = 5;
//    findShortestPath(graph, start, end, 7);
//
//    return 0;
//}
