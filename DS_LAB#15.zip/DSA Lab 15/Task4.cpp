#include <iostream>
using namespace std;

const int MAX = 100;
const int INF = 1e9;

void primAlgorithm(int graph[MAX][MAX], int vertices, int start)
{
    int key[MAX], parent[MAX];
    bool included[MAX];
    int totalCost = 0;

    for (int i = 1; i <= vertices; i++)
    {
        key[i] = INF;
        included[i] = false;
        parent[i] = -1;
    }

    key[start] = 0;

    for (int i = 1; i <= vertices; i++)
    {
        int minKey = INF;
        int current = -1;

        for (int j = 1; j <= vertices; j++)
        {
            if (!included[j] && key[j] < minKey)
            {
                minKey = key[j];
                current = j;
            }
        }

        included[current] = true;

        for (int j = 1; j <= vertices; j++)
        {
            if (graph[current][j] > 0 && !included[j] && graph[current][j] < key[j])
            {
                key[j] = graph[current][j];
                parent[j] = current;
            }
        }
    }

    cout << "Selected connections: ";
    for (int i = 2; i <= vertices; i++)
    {
        if (parent[i] != -1)
        {
            cout << "(" << parent[i] << ", " << i << ") ";
            totalCost += graph[parent[i]][i];
        }
    }
    cout << "\nTotal cost: " << totalCost << endl;
}

int main()
{
    int vertices = 4;
    int graph[MAX][MAX] = { 0 };

    graph[1][2] = 1;
    graph[2][1] = 1;
    graph[1][3] = 4;
    graph[3][1] = 4;
    graph[1][4] = 5;
    graph[4][1] = 5;
    graph[2][3] = 2;
    graph[3][2] = 2;
    graph[3][4] = 3;
    graph[4][3] = 3;

    primAlgorithm(graph, vertices, 1);

    return 0;
}
