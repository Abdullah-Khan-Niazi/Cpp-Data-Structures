#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node() : data(0), next(nullptr) {}
};
class list {
private:
    Node* head;
    Node* current;
public:
    list() : head(nullptr), current(nullptr) {}
    void insert(int val) {
        Node* newNode = new Node;
        newNode->data = val;
        if (head == nullptr) {
            head = newNode;
        }
        else {
            current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = newNode;
        }
    }
    void print() {
        current = head;
        while (current != nullptr) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
};
struct AdjNode {
    int data;
    AdjNode* next;
    list obj;
    AdjNode() : data(0), next(nullptr) {}
};
class adjList {
private:
    AdjNode* head;
    AdjNode* current;
    int vertexCount;
public:
    adjList() : head(nullptr), current(nullptr) , vertexCount(0) {}
    void insertVertex() {
        AdjNode* newVertex = new AdjNode;
        newVertex->data = vertexCount++;
        if (head == nullptr) {
            head = newVertex;
        }
        else {
            current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = newVertex;
        }
    }
    void insertAtVertex(int vertex, int val) {
        current = head;
        while (current != nullptr && current->data != vertex) {
            current = current->next;
        }
        if (current == nullptr) {
            cout << "Vertex# " << vertex << " Not Found!" << endl;
            return;
        }
        current->obj.insert(val);
    }
    void print() {
        current = head;
        while (current != nullptr) {
            cout << current->data << " : ";
            current->obj.print();
            current = current->next;
        }
    }
};
int main() {
    adjList obj;
    obj.insertVertex();
    obj.insertVertex(); 
    obj.insertVertex();
    obj.insertVertex();
    obj.insertVertex();
    obj.insertVertex();
    obj.insertVertex();

    obj.insertAtVertex(0, 1);
    obj.insertAtVertex(0, 4);

    obj.insertAtVertex(1, 5);
    obj.insertAtVertex(1, 0);
    obj.insertAtVertex(1, 3);
    obj.insertAtVertex(1, 6);

    obj.insertAtVertex(2, 6);
    obj.insertAtVertex(2, 5);

    obj.insertAtVertex(3, 4);
    obj.insertAtVertex(3, 1);
    obj.insertAtVertex(3, 5);

    obj.insertAtVertex(4, 3);
    obj.insertAtVertex(4, 6);
    obj.insertAtVertex(4, 0);

    obj.insertAtVertex(5, 1);
    obj.insertAtVertex(5, 2);
    obj.insertAtVertex(5, 3);

    obj.insertAtVertex(6, 4);
    obj.insertAtVertex(6, 2);
    obj.insertAtVertex(6, 1);

    obj.print();
    return 0;
}
