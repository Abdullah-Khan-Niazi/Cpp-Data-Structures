#include<iostream>
using namespace std;

class Graph {
private:
    int** Data;
    int Size;
public:
    Graph(int size) : Size(size) {
        Data = new int* [Size];
        for (int i = 0; i < Size; i++) {
            Data[i] = new int[Size];
        }
        // Initialize all entries to 0
        for (int i = 0; i < Size; i++) {
            for (int j = 0; j < Size; j++) {
                Data[i][j] = 0;
            }
        }
    }

    void insert_edge(int index1, int index2, int weight) {
        // Check for valid index ranges
        if (index1 < 0 || index1 >= Size || index2 < 0 || index2 >= Size) {
            cout << "Wrong Index" << endl;
            return;
        }
        if (index1 != index2) {
            Data[index1][index2] = weight;
            Data[index2][index1] = weight;
        }
    }

    int smallest_weight() {
        int min = 10000;
        int index1 = -1, index2 = -1;
        // Search for the smallest edge weight
        for (int i = 0; i < Size; i++) {
            for (int j = 0; j < Size; j++) {
                if (Data[i][j] != 0 && Data[i][j] < min) {
                    min = Data[i][j];
                    index1 = i;
                    index2 = j;
                }
            }
        }
        // Display the smallest edge
        if (index1 != -1 && index2 != -1) {
            cout << "Edges With Smallest Weight are: (" << index1 << ", " << index2 << ") with weight " << min << endl;
        }
        else {
            cout << "No edges found." << endl;
        }
        return min;
    }
};

int main() {
    int size;
    cout << "Enter Size of The Graph: "; cin >> size;
    Graph obj1(size);

    int edge1, edge2, weight;
    for (int i = 0; i < size; i++) {
        cout << "Enter Edge#1: "; cin >> edge1;
        cout << "Enter Edge#2: "; cin >> edge2;
        cout << "Enter Weight of The Edge: "; cin >> weight;
        obj1.insert_edge(edge1, edge2, weight);
    }

    obj1.smallest_weight();
    return 0;
}
