//#include <iostream>
//using namespace std;
//
//struct Node {
//    int data;
//    Node* next;
//};
//
//class Queue {
//private:
//    Node* front;
//    Node* rear;
//    int numOfItems;
//
//public:
//    Queue() : front(nullptr), rear(nullptr), numOfItems(0) {}
//
//    ~Queue() {
//        while (!isEmpty()) {
//            int temp;
//            dequeue(temp);
//        }
//    }
//
//    bool isEmpty() {
//        return numOfItems == 0;
//    }
//
//    void enqueue(int value) {
//        Node* newNode = new Node{ value, nullptr };
//        if (isEmpty()) {
//            front = rear = newNode;
//        }
//        else {
//            rear->next = newNode;
//            rear = newNode;
//        }
//        numOfItems++;
//    }
//
//    bool dequeue(int& value) {
//        if (isEmpty()) {
//            return false;
//        }
//        Node* temp = front;
//        value = front->data;
//        front = front->next;
//        delete temp;
//        numOfItems--;
//        if (isEmpty()) {
//            rear = nullptr;
//        }
//        return true;
//    }
//
//    bool peek(int& value) {
//        if (isEmpty()) {
//            return false;
//        }
//        value = front->data;
//        return true;
//    }
//};
//
//Queue maxSumSlidingWindow(Queue& nums, int k) {
//    Queue result;
//    Queue window;
//    int windowSum = 0;
//    int maxSum = 0; //INT_MIN
//
//    // code of initial window
//    for (int i = 0; i < k; i++) {
//        int val;
//        if (nums.dequeue(val)) {
//            window.enqueue(val);
//            windowSum += val;
//        }
//        else {
//            while (!window.isEmpty()) {
//                int temp;
//                window.dequeue(temp);
//                nums.enqueue(temp);
//            }
//            return result;
//        }
//    }
//    maxSum = windowSum;
//    result.enqueue(maxSum);
//
//   
//    while (!nums.isEmpty()) {  //Sliding window Loop
//        int out, in;
//        window.dequeue(out);
//        nums.dequeue(in);
//
//        windowSum = windowSum - out + in;
//        maxSum = max(maxSum, windowSum);
//
//        window.enqueue(in);
//        result.enqueue(maxSum);
//    }
//
//    
//    while (!window.isEmpty()) { // Original Queue Restoring
//        int val;
//        window.dequeue(val);
//        nums.enqueue(val);
//    }
//
//    return result;
//}
//
//int main() {
//    Queue nums;
//    int input[] = { 1, 3, -1, -3, 5, 3, 6, 7 };
//    int k = 3;
//
//    for (int i = 0; i < 8; i++) {
//        nums.enqueue(input[i]);
//    }
//
//    Queue result = maxSumSlidingWindow(nums, k);
//
//    cout << "Max sum of sliding windows: ";
//    while (!result.isEmpty()) {
//        int sum;
//        result.dequeue(sum);
//        cout << sum << " ";
//    }
//    cout << endl;
//
//    return 0;
//}