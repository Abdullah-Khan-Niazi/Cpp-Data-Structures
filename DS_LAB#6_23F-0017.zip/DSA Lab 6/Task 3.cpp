#include <iostream>
using namespace std;

struct Node {
    string ID;
    int time;
};

class CircularQueue {
private:
    Node* arr;
    int front, rear, size, capacity;

public:
    CircularQueue(int cap) : front(-1), rear(-1), size(0), capacity(cap) {
        arr = new Node[capacity];
    }

    ~CircularQueue() {
        delete[] arr;
    }

    void Enqueue(string id, int t) {
        if (IsFull()) {
            cout << "Queue is full\n";
            return;
        }
        if (IsEmpty()) front = 0;
        rear = (rear + 1) % capacity;
        arr[rear] = { id, t };
        size++;
    }

    void Dequeue() {
        if (IsEmpty()) {
            cout << "Queue is empty\n";
            return;
        }
        if (front == rear) front = rear = -1;
        else front = (front + 1) % capacity;
        size--;
    }

    bool IsEmpty() {
        return size == 0;
    }

    bool IsFull() {
        return size == capacity;
    }

    void RoundRobin(int quantum) {
        while (!IsEmpty()) {
            Node current = arr[front];
            cout << "Executing task " << current.ID << " for " << min(quantum, current.time) << " units\n";

            current.time -= quantum;
            Dequeue();

            if (current.time > 0) {
                Enqueue(current.ID, current.time);
            }
        }
    }
};

int main() {
    CircularQueue rr(5);

    rr.Enqueue("T1", 10);
    rr.Enqueue("T2", 5);
    rr.Enqueue("T3", 8);

    cout << "Starting Round-Robin scheduling with time quantum 2:\n";
    rr.RoundRobin(2);

    return 0;
}