//#include <iostream>
//#include <stack>
//using namespace std;
//
//class Queue {
//private:
//    stack<int> stack1; // For enqueue
//    stack<int> stack2; // For dequeue
//
//public:
//    void enqueue(int x) {
//        stack1.push(x);
//    }
//
//    int dequeue() {
//        if (isEmpty()) {
//            cout << "Queue is empty" << endl;
//            return -1;
//        }
//
//        if (stack2.empty()) {
//            while (!stack1.empty()) {
//                stack2.push(stack1.top());
//                stack1.pop();
//            }
//        }
//
//        int x = stack2.top();
//        stack2.pop();
//        return x;
//    }
//
//    int peek() {
//        if (isEmpty()) {
//            cout << "Queue is empty" << endl;
//            return -1;
//        }
//
//        if (stack2.empty()) {
//            while (!stack1.empty()) {
//                stack2.push(stack1.top());
//                stack1.pop();
//            }
//        }
//
//        return stack2.top();
//    }
//
//    bool isEmpty() {
//        return (stack1.empty() && stack2.empty());
//    }
//};
//
//int main() {
//    Queue q;
//
//    cout << boolalpha;
//
//    cout << q.isEmpty() << endl; 
//
//    q.enqueue(20);
//    cout << (q.peek() == 20) << endl; 
//
//    q.enqueue(30);
//    q.enqueue(50);
//    cout << (q.peek() == 20) << endl; 
//
//    cout << (q.dequeue() == 20) << endl; 
//    cout << (q.peek() == 30) << endl; 
//
//    cout << q.isEmpty() << endl; 
//
//    return 0;
//}