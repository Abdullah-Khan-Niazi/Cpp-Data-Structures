//// Queue ADT using Array 
//
//#include<iostream>
//using namespace std;
//
//class CircularQueue {
//private:
//    int* queueArray;
//    int queueSize;
//    int front;
//    int rear;
//    int count;
//
//public:
//    CircularQueue(int size = 10) {
//        queueSize = size;
//        queueArray = new int[queueSize];
//        front = 0;
//        rear = -1;
//        count = 0;
//    }
//
//    ~CircularQueue() {
//        delete[] queueArray;
//    }
//
//    bool isEmpty() {
//        return (count == 0);
//    }
//
//    bool isFull() {
//        return (count == queueSize);
//    }
//
//    bool peek(int& element) {
//        if (isEmpty()) {
//            cout << "Queue is Empty." << endl;
//            return false;
//        }
//        element = queueArray[front];
//        return true;
//    }
//
//    void enqueue(int value) {
//        if (isFull()) {
//            cout << "Queue is Full." << endl;
//            return;
//        }
//
//        rear = (rear + 1) % queueSize;
//        queueArray[rear] = value;
//        count++;
//        cout << value << " enqueued." << endl;
//    }
//
//    bool dequeue(int& element) {
//        if (isEmpty()) {
//            cout << "Queue is Empty." << endl;
//            return false;
//        }
//        element = queueArray[front];
//        front = (front + 1) % queueSize; 
//        count--;
//        return true;
//    }
//
//    void makeNull() {
//        front = 0;
//        rear = -1;
//        count = 0;
//        cout << "Now Queue is Empty." << endl;
//    }
//
//    int size() {
//        return count;
//    }
//};
//
//int main() {
//
//    CircularQueue q(5);
//
//    q.enqueue(10);
//    q.enqueue(20);
//    q.enqueue(30);
//    q.enqueue(40);
//    q.enqueue(50);
//
//    int element;
//
//    q.peek(element);
//    cout << "Front Element: " << element << endl;
//
//    q.dequeue(element);
//    cout << "Dequeued Element: " << element << endl;
//
//    q.peek(element);
//    cout << "Front Element: " << element << endl;
//
//    q.enqueue(60);
//    q.peek(element);
//    cout << "Front Element: " << element << endl;
//
//    q.makeNull();
//    q.peek(element);
//
//    return 0;
//}
//
//
//
//
//// Queue ADT using LinkedList based implementation
//
//#include<iostream>
//using namespace std;
//
//struct Node {
//	int data;
//	Node* next;
//};
//
//class Queue {
//private:
//	Node* front;
//	Node* rear;
//	int numOfItems;
//public:
//	Queue() {
//		front = nullptr;
//		rear = nullptr;
//		numOfItems = 0;
//	}
//
//	~Queue() {
//		makeNull();
//	}
//
//	bool isEmpty() {
//		return numOfItems == 0;
//	}
//
//	void enqueue(int value) {
//		Node* newNode = new Node;
//		newNode->data = value;
//		newNode->next = nullptr;
//
//		if (isEmpty()) {
//			front = newNode;
//			rear = newNode;
//		}
//		else {
//			rear->next = newNode;
//			rear = newNode;
//		}
//
//		numOfItems++;
//		cout << value << " enqueued." << endl;
//	}
//
//	bool dequeue(int& value) {
//		if (isEmpty()) {
//			cout << "Queue is Empty." << endl;
//			return false;
//		}
//
//		Node* temp = front;
//		value = front->data;
//		front = front->next;
//
//		delete temp;
//		numOfItems--;
//
//		if (numOfItems == 0) {
//			rear = nullptr;
//		}
//		return true;
//	}
//
//	bool peek(int& value) {
//		if (isEmpty()) {
//			cout << "Queue is Empty. " << endl;
//			return false;
//		}
//		value = front->data;
//		return true;
//	}
//
//	void makeNull() {
//		while (isEmpty()) {
//			int val;
//			dequeue(val);
//		}
//		cout << "Queue is Now Empty" << endl;
//	}
//};
//
//int main() {
//
//	Queue q;
//	q.enqueue(10);
//	q.enqueue(20);
//	q.enqueue(30);
//	q.enqueue(40);
//	q.enqueue(50);
//
//	int element;
//	q.peek(element);
//	cout << "Front Element: " << element << endl;
//
//	q.dequeue(element);
//	cout << "Dequeued Element: " << element << endl;
//	q.peek(element);
//	cout << "Front Element: " << element << endl;
//
//	q.enqueue(60);
//	q.peek(element);
//	cout << "Front Element: " << element << endl;
//
//	q.makeNull();
//	q.peek(element);
//
//	return 0;
//}