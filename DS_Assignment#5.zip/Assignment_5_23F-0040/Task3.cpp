//#include <iostream>
//using namespace std;
//
//class ProductCatalog
//{
//private:
//    struct Node
//    {
//        int key;
//        Node* next;
//    };
//
//    int** bucketTable;
//    Node** chainTable;
//    bool useChaining;
//    int tableSize;
//    int bucketCapacity;
//
//    int hashFunction(int key)
//    {
//        return key % tableSize;
//    }
//
//public:
//    ProductCatalog(int size, bool chaining)
//    {
//        tableSize = size;
//        useChaining = chaining;
//        bucketCapacity = 3;
//
//        if (useChaining)
//        {
//            chainTable = new Node * [tableSize];
//            for (int i = 0; i < tableSize; i++)
//            {
//                chainTable[i] = nullptr;
//            }
//        }
//        else
//        {
//            bucketTable = new int* [tableSize];
//            for (int i = 0; i < tableSize; i++)
//            {
//                bucketTable[i] = new int[bucketCapacity];
//                for (int j = 0; j < bucketCapacity; j++)
//                {
//                    bucketTable[i][j] = -1;
//                }
//            }
//        }
//    }
//
//    ~ProductCatalog()
//    {
//        if (useChaining)
//        {
//            for (int i = 0; i < tableSize; i++)
//            {
//                Node* current = chainTable[i];
//                while (current)
//                {
//                    Node* temp = current;
//                    current = current->next;
//                    delete temp;
//                }
//            }
//            delete[] chainTable;
//        }
//        else
//        {
//            for (int i = 0; i < tableSize; i++)
//            {
//                delete[] bucketTable[i];
//            }
//            delete[] bucketTable;
//        }
//    }
//
//    void insert(int key)
//    {
//        int index = hashFunction(key);
//
//        if (useChaining)
//        {
//            Node* newNode = new Node;
//            newNode->key = key;
//            newNode->next = chainTable[index];
//            chainTable[index] = newNode;
//        }
//        else
//        {
//            for (int i = 0; i < bucketCapacity; i++)
//            {
//                if (bucketTable[index][i] == -1)
//                {
//                    bucketTable[index][i] = key;
//                    return;
//                }
//            }
//        }
//    }
//
//    void display()
//    {
//        if (useChaining)
//        {
//            for (int i = 0; i < tableSize; i++)
//            {
//                cout << i << ": ";
//                Node* current = chainTable[i];
//                while (current)
//                {
//                    cout << current->key << " -> ";
//                    current = current->next;
//                }
//                cout << "NULL\n";
//            }
//        }
//        else
//        {
//            for (int i = 0; i < tableSize; i++)
//            {
//                cout << i << ": ";
//                for (int j = 0; j < bucketCapacity; j++)
//                {
//                    if (bucketTable[i][j] != -1)
//                    {
//                        cout << bucketTable[i][j] << " ";
//                    }
//                }
//                cout << "\n";
//            }
//        }
//    }
//};
//
//int main()
//{
//    int skus[] = { 17, 26, 15, 9, 11, 43, 75, 19, 35, 45, 55, 9, 10, 21, 61, 23 };
//    int n = sizeof(skus) / sizeof(skus[0]);
//
//    ProductCatalog catalog1(15, true);
//    ProductCatalog catalog2(15, false);
//
//    cout << "Using Chaining:\n";
//    for (int i = 0; i < n; i++)
//    {
//        catalog1.insert(skus[i]);
//    }
//    catalog1.display();
//
//    cout << "\nUsing Bucketing:\n";
//    for (int i = 0; i < n; i++)
//    {
//        catalog2.insert(skus[i]);
//    }
//    catalog2.display();
//
//    return 0;
//}
