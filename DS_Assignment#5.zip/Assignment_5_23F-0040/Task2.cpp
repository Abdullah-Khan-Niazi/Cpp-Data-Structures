#include <iostream>
using namespace std;

class LibraryHash
{
private:
    int* table;
    bool* occupied;
    int tableSize;
    bool doubleHashing;

    int hash1(int key)
    {
        return key % tableSize;
    }

    int hash2(int key)
    {
        return 1 + (key % (tableSize - 1));
    }

    int findSlot(int key)
    {
        int index = hash1(key);
        int step = doubleHashing ? hash2(key) : 1;

        while (occupied[index])
        {
            index = (index + step) % tableSize;
        }
        return index;
    }

public:
    LibraryHash(int size, bool useDoubleHashing = false)
    {
        tableSize = size;
        doubleHashing = useDoubleHashing;
        table = new int[tableSize];
        occupied = new bool[tableSize];

        for (int i = 0; i < tableSize; i++)
        {
            table[i] = -1;
            occupied[i] = false;
        }
    }

    ~LibraryHash()
    {
        delete[] table;
        delete[] occupied;
    }

    void insert(int key)
    {
        int index = findSlot(key);
        table[index] = key;
        occupied[index] = true;
    }

    void display()
    {
        for (int i = 0; i < tableSize; i++)
        {
            if (occupied[i])
            {
                cout << i << ": " << table[i] << "\n";
            }
            else
            {
                cout << i << ": EMPTY\n";
            }
        }
    }
};

int main()
{
    int size = 15; 
    LibraryHash hashTable1(size, false); 
    LibraryHash hashTable2(size, true);  

    int n;
    cout << "Enter the number of ISBNs to insert: ";
    cin >> n;

    cout << "Enter the ISBNs:\n";
    for (int i = 0; i < n; i++)
    {
        int isbn;
        cin >> isbn;

        hashTable1.insert(isbn);
        hashTable2.insert(isbn);
    }

    cout << "First strategy (linear probing):\n";
    hashTable1.display();

    cout << "Second strategy (double hashing):\n";
    hashTable2.display();

    return 0;
}
