#include <iostream>
#include <cstring>
using namespace std;

class HashSystem
{
private:
    struct Node
    {
        char* signature;
        Node* next;
    };

    Node** table;
    int tableSize;

    int hashFunction(const char* key)
    {
        int hash = 0;
        for (int i = 0; key[i] != '\0'; i++)
        {
            hash = (hash * 31 + key[i]) % tableSize;
        }
        return hash;
    }

    void insert(const char* key)
    {
        int index = hashFunction(key);
        Node* newNode = new Node;
        newNode->signature = new char[strlen(key) + 1];
        strcpy_s(newNode->signature, strlen(key) + 1, key); 
        newNode->next = table[index];
        table[index] = newNode;
    }


    bool search(const char* key)
    {
        int index = hashFunction(key);
        Node* current = table[index];
        while (current != nullptr)
        {
            if (strcmp(current->signature, key) == 0)
            {
                return true;
            }
            current = current->next;
        }
        return false;
    }

public:
    HashSystem(int size)
    {
        tableSize = size;
        table = new Node * [tableSize];
        for (int i = 0; i < tableSize; i++)
        {
            table[i] = nullptr;
        }
    }

    ~HashSystem()
    {
        for (int i = 0; i < tableSize; i++)
        {
            Node* current = table[i];
            while (current != nullptr)
            {
                Node* temp = current;
                current = current->next;
                delete[] temp->signature;
                delete temp;
            }
        }
        delete[] table;
    }

    void processPacket(const char* packet)
    {
        if (!search(packet))
        {
            insert(packet);
        }
    }

    bool checkThreat(const char* signature)
    {
        return search(signature);
    }

    void displayTable()
    {
        for (int i = 0; i < tableSize; i++)
        {
            cout << i << ": ";
            Node* current = table[i];
            while (current != nullptr)
            {
                cout << current->signature << " -> ";
                current = current->next;
            }
            cout << "NULL\n";
        }
    }
};

int main()
{
    HashSystem hs(1000);

    hs.processPacket("packet1");
    hs.processPacket("packet2");
    hs.displayTable();

    if (hs.checkThreat("packet1"))
    {
        cout << "Threat Detected\n";
    }
    else
    {
        cout << "No Threat\n";
    }

    return 0;
}
